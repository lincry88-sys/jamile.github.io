package inicio;


public class Inicio {


    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
