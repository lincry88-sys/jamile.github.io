<?php
// Este archivo muestra el formulario y los mensajes (usa GET status para mensajes)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reserva de autos</title>
    <link rel="icon" type="image/png" href="imagenes/logo1.png">
    <link rel="stylesheet" href="estilo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

    <header class="logo-fijo">
        <img src="imagenes/logo1.png" alt="Logo" class="logo">
    </header>

    <div class="formulario">
        <h2>Reserva de autos</h2>

        <!-- Mensajes -->
        <?php if(isset($_GET['status']) && $_GET['status'] === 'ok'): ?>
            <div class="msg success">✅ Reserva guardada correctamente.</div>
        <?php elseif(isset($_GET['status']) && $_GET['status'] === 'error'): ?>
            <div class="msg error">❌ Hubo un error al guardar. Intenta nuevamente.</div>
        <?php elseif(isset($_GET['status']) && $_GET['status'] === 'empty'): ?>
            <div class="msg error">⚠️ Faltan campos requeridos.</div>
        <?php endif; ?>

        <form action="guardar.php" method="post">
            <label for="nombre">Nombre completo:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Ej: Juan Pérez" required>

            <label for="correo">Correo electrónico:</label>
            <input type="email" id="correo" name="correo" placeholder="Ej: juan@gmail.com" required>

            <label for="telefono">Teléfono:</label>
            <input type="tel" id="telefono" name="telefono" placeholder="Ej: +593 000 000 000" required>

            <label for="modelo">Seleccione un modelo:</label>
            <select id="modelo" name="modelo" required>
                <option value="">Seleccione</option>
                <option value="cayenne">Porsche Cayenne S</option>
                <option value="taycan">Porsche Taycan GT</option>
                <option value="911">Porsche 911 GT3</option>
                <option value="macan">Porsche Macan S</option>
                <option value="panamera">Porsche Panamera Turbo</option>
                <option value="718">Porsche 718 Cayman</option>
                <option value="boxster">Porsche Boxster T</option>
            </select>

            <label for="fecha">Fecha de prueba:</label>
            <input type="date" id="fecha" name="fecha" required>

            <label for="hora">Hora preferida:</label>
            <input type="time" id="hora" name="hora" required>

            <label for="comentarios">Comentarios adicionales:</label>
            <textarea id="comentarios" name="comentarios" rows="3" placeholder="Ej: Me gustaría probar la versión híbrida..."></textarea>

            <label class="terminos">
                <input type="checkbox" name="terminos" required>
                Acepto los términos y condiciones
            </label>

            <button type="submit" class="boton">Reservar prueba</button>
        </form>

        <div class="pie">© 2025 Reservación de Autos</div>
    </div>

</body>
</html>
