<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reserva Exitosa</title>
<link rel="stylesheet" href="estilo.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
/* Contenedor similar al formulario */
.success-container {
    background: rgba(40, 40, 40, 0.85);
    border-radius: 16px;
    padding: 35px 50px 40px 50px;
    width: 620px;
    box-shadow: 0 5px 30px rgba(255, 215, 0, 0.25);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 215, 0, 0.15);
    transition: all 0.3s ease;
    margin: 80px auto;
    text-align: center;
    position: relative;
    top: 20px;
}

.success-container h1 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 28px;
    color: #00ff6a; /* Verde éxito */
    text-shadow: 0 0 6px rgba(0, 255, 100, 0.5);
}

.success-container p {
    font-size: 16px;
    color: #f0f0f0;
    margin-bottom: 25px;
}

/* Botón de volver */
.success-container a button {
    width: 200px;
    background: linear-gradient(90deg, #b12b28, #ff3d3a);
    color: #fff;
    font-weight: bold;
    padding: 12px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
    transition: all 0.3s ease;
    box-shadow: 0 0 8px rgba(177, 43, 40, 0.4);
}

.success-container a button:hover {
    background: linear-gradient(90deg, #ff3d3a, #ff6f61);
    box-shadow: 0 0 15px rgba(255, 50, 50, 0.6);
    transform: scale(1.04);
}
</style>
</head>
<body>

<div class="success-container">
    <h1>✅ ¡Guardado correctamente!</h1>
    <p>Tu reserva ha sido registrada con éxito.</p>
    <a href="formulario.php"><button>Volver al formulario</button></a>
</div>

</body>
</html>
