<?php
// guardar.php — recibe POST, inserta en la tabla y redirige con status

// Datos de conexión
$host = "localhost";
$user = "root";
$pass = "";
$db   = "formularioo";   // <- si tu base tiene otro nombre cámbialo aquí

$mysqli = new mysqli($host, $user, $pass, $db);
if ($mysqli->connect_errno) {
    // Si hay error de conexión, redirigir con error
    header("Location: formularioo.php?status=error");
    exit();
}

// Validar existencia de campos requeridos (puedes ampliar validaciones)
if (!isset($_POST['nombre'], $_POST['correo'], $_POST['telefono'], $_POST['modelo'], $_POST['fecha'], $_POST['hora'])) {
    header("Location: formularioo.php?status=empty");
    exit();
}

// Recoger y sanitizar (mínimo)
$nombre     = trim($_POST['nombre']);
$correo     = trim($_POST['correo']);
$telefono   = trim($_POST['telefono']);
$modelo     = trim($_POST['modelo']);
$fecha      = trim($_POST['fecha']);
$hora       = trim($_POST['hora']);
$comentarios= isset($_POST['comentarios']) ? trim($_POST['comentarios']) : NULL;

// Prepared statement para evitar SQL injection
$stmt = $mysqli->prepare("INSERT INTO formularioo (nombre, correo, telefono, modelo, fecha, hora, comentarios) VALUES (?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    header("Location: formularioo.php?status=error");
    exit();
}

// todos son strings; si necesitas cambiar tipos, ajusta bind_param
$stmt->bind_param("sssssss", $nombre, $correo, $telefono, $modelo, $fecha, $hora, $comentarios);

if ($stmt->execute()) {
    $stmt->close();
    $mysqli->close();
    header("Location: exito.php?status=ok");
    exit();
} else {
    $stmt->close();
    $mysqli->close();
    header("Location: formularioo.php?status=error");
    exit();
}
?>
